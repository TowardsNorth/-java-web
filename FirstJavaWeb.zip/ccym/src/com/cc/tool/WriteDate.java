package com.cc.tool;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WriteDate {
	
	private String Newdate = "";

	public  String getWriteDate(){
		//ת��ʱ���ʽ
				Date date = new Date();
				DateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 	
				try {
					Newdate = sdf2.format(date);
				} catch (Exception e) {
					e.printStackTrace();
				}
				return Newdate;		
	}

	
//	public static void main(String[] args) {
//		WriteDate w = new WriteDate();
//		w.getWriteDate();
//		System.out.println(w.getWriteDate());
//
//	}
}
