package com.cc.dao;

import java.sql.Connection;

import com.cc.dbmanager.DBConnection;

public class BaseDao {

	Connection conn =null;
	public Connection getConn(){
		DBConnection db = new DBConnection();
		conn  = db.getConn();
		return conn;
	}

}
