package com.cc.dao.impl;

import java.sql.*;

import com.cc.dao.BaseDao;
import com.cc.dao.IUserDao;
import com.cc.entity.User;

public class UserDaoImpl extends BaseDao implements IUserDao {

	public int addOneUser(User user) {

		// �����û�����ϸ����
		int i = 0;
		String sql = "insert into users values(0,?,?)";
		Connection conn = this.getConn();
		try {
			PreparedStatement preStmt = conn.prepareStatement(sql);
			preStmt.setString(1, user.getUserName());
			preStmt.setString(2, user.getUserPass());
			i = preStmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return i;
	}
}

