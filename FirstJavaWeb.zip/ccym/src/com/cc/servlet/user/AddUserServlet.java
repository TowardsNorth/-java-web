package com.cc.servlet.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cc.dao.IUserDao;
import com.cc.dao.impl.UserDaoImpl;
import com.cc.entity.User;
import com.cc.tool.WriteDate;

/**
 * Servlet implementation class AddUserServlet
 */
@WebServlet("/AddUserServlet")
public class AddUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doreg(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doreg(request,response);
	}
	
	
	protected void doreg(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

				req.setCharacterEncoding("utf-8");
				resp.setCharacterEncoding("utf-8");
			
		
				//ͨ��request���õ��ύ�ı����е�ֵ
				String UserName = req.getParameter("UserName");
				String UserPass = req.getParameter("UserPass");
				
				
				//����ʵ��
				User user = new User();
				user.setUserName(UserName);
				user.setUserPass(UserPass);
				
				//dao->ʵ����
				IUserDao dao = new UserDaoImpl();
				int  i = dao.addOneUser(user);
				if(i>0)
					req.getRequestDispatcher("success.jsp").forward(req,resp);
				else
					req.getRequestDispatcher("error.jsp").forward(req,resp);
			
		}

}
