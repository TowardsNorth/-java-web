package com.cc.dbmanager;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class DBConnection {
	
	private Connection conn;// ���ݿ����Ӷ���

	private PreparedStatement stmt;// Ԥ�������
	
	private CallableStatement  sc;

	private ResultSet rs;// ���������
	
	private String dbDriver = "com.mysql.jdbc.Driver";
	private String dbUrl = "jdbc:mysql://localhost:3306/tian";
	private String dbUser ="root";
	private String dbPass ="000000";
	
	public Connection getConn()
	{
		Connection conn = null;
		try {
			Class.forName(dbDriver);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		try {
			 conn = DriverManager.getConnection(dbUrl,dbUser,dbPass);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return conn;
	}

	

}
