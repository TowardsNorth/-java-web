CREATE DATABASE tian;
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `userId` int(10) NOT NULL auto_increment,
  `userName` varchar(20) character set utf8 collate utf8_bin default NULL,
  `userPass` varchar(20) character set utf8 default NULL,
  PRIMARY KEY  (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of user
-- ----------------------------

